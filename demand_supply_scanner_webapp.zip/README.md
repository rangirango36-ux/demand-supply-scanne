# Demand & Supply Zone Scanner

Streamlit web app for the custom rule-based scanner.

## Files
- `app.py`: website app
- `requirements.txt`: Python dependencies

## Deploy
Upload both files to a GitHub repository, then create a Streamlit Community Cloud app using `app.py` as the main file.

The app downloads data through Yahoo Finance/yfinance. Daily/weekly/monthly request maximum available history; intraday data is limited by the provider. This is an educational candidate-zone detector, not financial advice.
